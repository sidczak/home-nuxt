<!-- Please remove this file from your project -->
<template>
  <div
    class="relative flex items-top justify-center min-h-screen bg-gray-100 sm:items-center sm:pt-0"
  >
    <link
      href="https://cdn.jsdelivr.net/npm/tailwindcss@2.1.2/dist/tailwind.min.css"
      rel="stylesheet"
    />
    <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
      <a
        class="flex justify-center pt-8 sm:pt-0"
        href="https://nuxtjs.org"
        target="_blank"
      >
        <svg class="h-16" width="296" height="87" viewBox="0 0 296 87" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M102 27.476h8.755l18.556 29.6674V27.476h8.082v42.0374h-8.696l-18.615-29.6058v29.6058H102V27.476ZM173.519 69.5132h-7.531v-4.6956c-1.715 3.3045-5.204 5.1651-9.612 5.1651-6.981 0-11.514-4.9245-11.514-12.0119V39.2441h7.532v17.1772c0 4.1438 2.573 7.0258 6.43 7.0258 4.225 0 7.164-3.243 7.164-7.6862V39.2441h7.531v30.2691ZM199.729 69.0347l-7.226-10.0897-7.227 10.0897h-8.022L188.4 53.2398l-10.287-14.4742h8.204l6.186 8.7104 6.122-8.7104h8.267l-10.35 14.4742 11.146 15.7949h-7.959ZM222.997 30.1165v9.127h8.572V45.43h-8.572v15.0259c0 .5047.204.9887.567 1.3458.364.3571.857.5581 1.372.5589h6.633v7.1402h-4.961c-6.735 0-11.143-3.8445-11.143-10.5651V45.4359h-6.062v-6.1924h3.803c1.774 0 2.807-1.0359 2.807-2.7498v-6.3772h6.984ZM250.556 59.993V27.476h8.079v30.0254c0 8.1087-3.98 12.012-10.715 12.012h-9.405v-7.1403h9.614c.644 0 1.261-.2508 1.716-.6971.455-.4464.711-1.0517.711-1.683ZM263.477 55.3996h7.78c.431 4.6956 3.614 7.6861 8.758 7.6861 4.593 0 7.78-1.799 7.78-5.5232 0-9.0097-23.04-2.7645-23.04-18.8587C264.76 31.7983 270.823 27 279.533 27c9.064 0 15.186 5.1035 15.56 12.9716h-7.738c-.365-3.6626-3.291-6.1248-7.837-6.1248-4.225 0-6.858 1.9222-6.858 4.8629 0 9.309 23.34 2.3478 23.34 18.7384C296 65.2545 289.447 70 280.018 70c-9.737 0-16.104-5.7668-16.532-14.5945" fill="#012A35"/><path fill-rule="evenodd" clip-rule="evenodd" d="M39.115 19.0524c-2.2607-3.8871-7.9124-3.8871-10.1731 0L4.30396 61.4154c-2.26069 3.8871.56516 8.7459 5.08654 8.7459h19.2337c-1.9321-1.6885-2.6475-4.6094-1.1855-7.1155l18.6598-31.9859-6.9835-12.0075Z" fill="#80EEC0"/><path d="M54.726 28.3449c1.8709-3.1803 6.5482-3.1803 8.4191 0l20.39 34.6606c1.871 3.1804-.4677 7.1558-4.2095 7.1558H38.5455c-3.7418 0-6.0805-3.9754-4.2095-7.1558l20.39-34.6606Z" fill="#00DC82"/></svg>
      </a>
      <div class="mt-8 bg-white overflow-hidden shadow sm:rounded-lg p-6">
        <h2 class="text-2xl leading-7 font-semibold">
          Welcome to your Nuxt Application
        </h2>
        <p class="mt-3 text-gray-600">
          We recommend you take a look at the
          <a
            href="https://nuxtjs.org"
            target="_blank"
            class="text-green-500 hover:underline"
            >Nuxt documentation</a
          >, whether you are new or have previous experience with the
          framework.<br />
        </p>
        <p class="mt-4 pt-4 text-gray-800 border-t border-dashed">
          To get started, remove
          <code class="bg-gray-100 text-sm p-1 rounded border"
            >components/Tutorial.vue</code
          >
          and start coding in
          <code class="bg-gray-100 text-sm p-1 rounded border"
            >pages/index.vue</code
          >. Have fun!
        </p>
      </div>
      <div class="flex justify-center pt-4 space-x-2">
        <a href="https://github.com/nuxt/nuxt.js" target="_blank"
          ><svg
            class="w-6 h-6 text-gray-600 hover:text-gray-800"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            aria-hidden="true"
            role="img"
            width="32"
            height="32"
            preserveAspectRatio="xMidYMid meet"
            viewBox="0 0 24 24"
          >
            <path
              d="M12 2.247a10 10 0 0 0-3.162 19.487c.5.088.687-.212.687-.475c0-.237-.012-1.025-.012-1.862c-2.513.462-3.163-.613-3.363-1.175a3.636 3.636 0 0 0-1.025-1.413c-.35-.187-.85-.65-.013-.662a2.001 2.001 0 0 1 1.538 1.025a2.137 2.137 0 0 0 2.912.825a2.104 2.104 0 0 1 .638-1.338c-2.225-.25-4.55-1.112-4.55-4.937a3.892 3.892 0 0 1 1.025-2.688a3.594 3.594 0 0 1 .1-2.65s.837-.262 2.75 1.025a9.427 9.427 0 0 1 5 0c1.912-1.3 2.75-1.025 2.75-1.025a3.593 3.593 0 0 1 .1 2.65a3.869 3.869 0 0 1 1.025 2.688c0 3.837-2.338 4.687-4.563 4.937a2.368 2.368 0 0 1 .675 1.85c0 1.338-.012 2.413-.012 2.75c0 .263.187.575.687.475A10.005 10.005 0 0 0 12 2.247z"
              fill="currentColor"
            /></svg
        ></a>
        <a href="https://twitter.com/nuxt_js" target="_blank"
          ><svg
            class="w-6 h-6 text-gray-600 hover:text-gray-800"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            aria-hidden="true"
            role="img"
            width="32"
            height="32"
            preserveAspectRatio="xMidYMid meet"
            viewBox="0 0 24 24"
          >
            <path
              d="M22.46 6c-.77.35-1.6.58-2.46.69c.88-.53 1.56-1.37 1.88-2.38c-.83.5-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29c0 .34.04.67.11.98C8.28 9.09 5.11 7.38 3 4.79c-.37.63-.58 1.37-.58 2.15c0 1.49.75 2.81 1.91 3.56c-.71 0-1.37-.2-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 0 1-1.93.07a4.28 4.28 0 0 0 4 2.98a8.521 8.521 0 0 1-5.33 1.84c-.34 0-.68-.02-1.02-.06C3.44 20.29 5.7 21 8.12 21C16 21 20.33 14.46 20.33 8.79c0-.19 0-.37-.01-.56c.84-.6 1.56-1.36 2.14-2.23z"
              fill="currentColor"
            /></svg
        ></a>
      </div>
    </div>
  </div>
</template>
